class Track {
  final String id;
  final String title;
  final String artist;
  final String album;
  final String? path;
  final String? artwork;
  final Duration duration;
  final String genre;

  const Track({
    required this.id,
    required this.title,
    required this.artist,
    this.album = 'Unknown Album',
    this.path,
    this.artwork,
    this.duration = Duration.zero,
    this.genre = 'Other',
  });

  bool get isPlayable => path != null && path!.isNotEmpty;
}
