import 'package:flutter/material.dart';

class PlayerScreen extends StatelessWidget {
  const PlayerScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Now Playing'), backgroundColor: Colors.transparent),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 280, height: 280,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            gradient: const LinearGradient(colors: [Color(0xFF39316F), Color(0xFF171B35)]),
            boxShadow: [BoxShadow(color: const Color(0xFF8B6CFF).withOpacity(.18), blurRadius: 45)],
          ),
          child: const Icon(Icons.album_rounded, size: 120, color: Colors.white70)),
        const SizedBox(height: 30),
        const Text('Nothing playing', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Add an audio file from Home to start your library.',
          style: TextStyle(color: Colors.white54)),
        const SizedBox(height: 30),
        const LinearProgressIndicator(value: 0, minHeight: 4),
        const SizedBox(height: 20),
        const Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          Icon(Icons.shuffle_rounded, color: Colors.white38),
          Icon(Icons.skip_previous_rounded, size: 36),
          Icon(Icons.play_circle_fill_rounded, size: 64, color: Color(0xFF9B86FF)),
          Icon(Icons.skip_next_rounded, size: 36),
          Icon(Icons.repeat_rounded, color: Colors.white38),
        ]),
      ]),
    ),
  );
}
