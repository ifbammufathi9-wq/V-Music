import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool dynamicColor = true;
  bool normalization = false;
  bool gapless = true;
  String quality = 'High';
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Settings'), backgroundColor: Colors.transparent),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('PLAYBACK', style: TextStyle(color: Color(0xFFAA9BFF), fontWeight: FontWeight.bold)),
      SwitchListTile(title: const Text('Dynamic background'), value: dynamicColor,
        onChanged: (v) => setState(() => dynamicColor = v)),
      SwitchListTile(title: const Text('Audio normalization'), value: normalization,
        onChanged: (v) => setState(() => normalization = v)),
      SwitchListTile(title: const Text('Gapless playback'), value: gapless,
        onChanged: (v) => setState(() => gapless = v)),
      ListTile(title: const Text('Audio quality'), subtitle: Text(quality),
        trailing: DropdownButton<String>(value: quality,
          items: ['Low', 'Normal', 'High', 'Lossless'].map((q) =>
            DropdownMenuItem(value: q, child: Text(q))).toList(),
          onChanged: (v) => setState(() => quality = v ?? quality))),
      const Divider(height: 32),
      const Text('APP', style: TextStyle(color: Color(0xFFAA9BFF), fontWeight: FontWeight.bold)),
      const ListTile(title: Text('Storage management'), subtitle: Text('Local files are not copied by default.')),
      const ListTile(title: Text('Privacy'), subtitle: Text('Account and cloud sync can be connected later.')),
      const ListTile(title: Text('About V-Music'), subtitle: Text('V-Music starter build • v1.0.0')),
    ]),
  );
}
