import 'package:flutter/material.dart';

class PlaylistScreen extends StatefulWidget {
  const PlaylistScreen({super.key});
  @override
  State<PlaylistScreen> createState() => _PlaylistScreenState();
}

class _PlaylistScreenState extends State<PlaylistScreen> {
  final List<String> _playlists = [];
  void _create() {
    final controller = TextEditingController();
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Create playlist'),
      content: TextField(controller: controller, autofocus: true,
        decoration: const InputDecoration(hintText: 'Playlist name')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () {
          final name = controller.text.trim();
          if (name.isNotEmpty) setState(() => _playlists.add(name));
          Navigator.pop(context);
        }, child: const Text('Create')),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.transparent,
    appBar: AppBar(title: const Text('Playlist'), backgroundColor: Colors.transparent,
      actions: [IconButton(onPressed: _create, icon: const Icon(Icons.add_rounded))]),
    body: _playlists.isEmpty
      ? const Center(child: Text('No playlists yet. Tap + to create one.',
          style: TextStyle(color: Colors.white54)))
      : ListView.builder(itemCount: _playlists.length, itemBuilder: (_, i) => ListTile(
          leading: const Icon(Icons.queue_music_rounded),
          title: Text(_playlists[i]),
          trailing: IconButton(icon: const Icon(Icons.delete_outline),
            onPressed: () => setState(() => _playlists.removeAt(i))),
        )),
  );
}
