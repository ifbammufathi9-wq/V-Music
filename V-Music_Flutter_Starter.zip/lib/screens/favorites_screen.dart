import 'package:flutter/material.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});
  @override
  Widget build(BuildContext context) => const Center(
    child: Padding(
      padding: EdgeInsets.all(28),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.favorite_border_rounded, size: 54, color: Color(0xFF9B86FF)),
        SizedBox(height: 14),
        Text('Your favorites', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Text('Liked songs will show up here after you add music and enable the library actions.',
          textAlign: TextAlign.center, style: TextStyle(color: Colors.white54)),
      ]),
    ),
  );
}
