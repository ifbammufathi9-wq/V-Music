import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../models/track.dart';
import '../widgets/track_tile.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<Track> _tracks = [];
  String get _greeting {
    final h = DateTime.now().hour;
    if (h < 11) return 'Good Morning';
    if (h < 17) return 'Good Afternoon';
    return 'Good Evening';
  }

  Future<void> _addAudio() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.audio, allowMultiple: true, withData: false,
    );
    if (result == null) return;
    final added = result.files.where((f) => f.path != null).map((f) => Track(
      id: f.path!, title: f.name.replaceAll(RegExp(r'\\.[^.]+$'), ''),
      artist: 'Local file', path: f.path,
    ));
    setState(() => _tracks.addAll(added));
  }

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(slivers: [
      SliverPadding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 18),
        sliver: SliverToBoxAdapter(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              const CircleAvatar(radius: 21, child: Icon(Icons.person)),
              const Spacer(),
              IconButton(onPressed: () => showSearch(context: context, delegate: _MusicSearch(_tracks)),
                  icon: const Icon(Icons.search_rounded)),
              IconButton(onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const _SettingsRoute())),
                  icon: const Icon(Icons.settings_rounded)),
            ]),
            const SizedBox(height: 22),
            Text(_greeting, style: const TextStyle(color: Colors.white60, fontSize: 15)),
            const Text('Your sound, your world.', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
            const SizedBox(height: 22),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                gradient: const LinearGradient(colors: [Color(0xFF302A61), Color(0xFF171B35)]),
              ),
              child: Row(children: [
                const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Build your library', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  SizedBox(height: 6),
                  Text('Import audio from your device to get started.',
                      style: TextStyle(color: Colors.white70)),
                ])),
                IconButton.filled(onPressed: _addAudio, icon: const Icon(Icons.add_rounded)),
              ]),
            ),
            const SizedBox(height: 26),
            _sectionTitle('Recently Added'),
            const SizedBox(height: 8),
          ],
        )),
      ),
      if (_tracks.isEmpty)
        const SliverFillRemaining(
          hasScrollBody: false,
          child: Center(child: Padding(
            padding: EdgeInsets.all(32),
            child: Text('Your music library is empty.\\nAdd your own audio when you’re ready.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, height: 1.6)),
          )),
        )
      else
        SliverList(delegate: SliverChildBuilderDelegate(
          (context, i) => TrackTile(track: _tracks[i]),
          childCount: _tracks.length,
        )),
      SliverToBoxAdapter(child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 100),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _sectionTitle('Made for you'),
          const SizedBox(height: 10),
          const Text('Recommendations will appear after listening activity is available.',
              style: TextStyle(color: Colors.white54)),
        ]),
      )),
    ]);
  }

  Widget _sectionTitle(String text) => Text(text,
      style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold));
}

class _MusicSearch extends SearchDelegate<String> {
  final List<Track> tracks;
  _MusicSearch(this.tracks);
  @override
  List<Widget>? buildActions(BuildContext context) => [
    IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))
  ];
  @override
  Widget? buildLeading(BuildContext context) => IconButton(
    onPressed: () => close(context, ''), icon: const Icon(Icons.arrow_back));
  @override
  Widget buildResults(BuildContext context) => _results();
  @override
  Widget buildSuggestions(BuildContext context) => _results();
  Widget _results() {
    final found = tracks.where((t) =>
      '${t.title} ${t.artist} ${t.album}'.toLowerCase().contains(query.toLowerCase())).toList();
    return ListView(children: found.map((t) => ListTile(
      title: Text(t.title), subtitle: Text(t.artist),
    )).toList());
  }
}

class _SettingsRoute extends StatelessWidget {
  const _SettingsRoute();
  @override
  Widget build(BuildContext context) => const SettingsScreen();
}
