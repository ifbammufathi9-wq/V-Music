import 'package:flutter/material.dart';
import 'package:audio_service/audio_service.dart';
import 'services/music_handler.dart';
import 'screens/app_shell.dart';

late final AudioHandler musicHandler;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  musicHandler = await AudioService.init(
    builder: () => MusicHandler(),
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'com.vmusic.playback',
      androidNotificationChannelName: 'V-Music Playback',
      androidNotificationOngoing: true,
      androidStopForegroundOnPause: true,
    ),
  );
  runApp(const VMusicApp());
}

class VMusicApp extends StatelessWidget {
  const VMusicApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'V-Music',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF090A12),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF8B6CFF),
          brightness: Brightness.dark,
          surface: const Color(0xFF121421),
        ),
        fontFamily: 'Roboto',
      ),
      home: const AppShell(),
    );
  }
}
