# V-Music starter — implementation status

This is a Flutter starter project, not a finished production streaming service.

## Included now
- Android/iOS Flutter project structure.
- Dark premium visual foundation and bottom navigation.
- Home page with time-based greeting.
- Local audio file picker on Home.
- Playlist creation and deletion in the current app session.
- Search over tracks imported into the current Home screen.
- Settings controls for dynamic background, normalization, gapless preference and quality selection (UI state only).
- `just_audio` + `audio_service` playback service foundation with notification/media-session hooks.
- Player screen shell.

## Important limitations
- No bundled music is included. Import an audio file to begin testing.
- The current Home screen imports file metadata for display; it is not yet wired to `MusicHandler.loadQueue`, so playback controls are scaffolding until the library/player integration is completed.
- Background audio service is configured in code, but Android/iOS native build configuration, permissions, lock-screen metadata, interruption tests and device tests still need to be completed.
- Favorites, persistent playlists, listening history, real statistics, dynamic artwork palette extraction, lyrics, recommendations, accounts, cloud database, public playlists and collaborative playlists are not implemented yet.
- Settings currently store only in widget state; persistent preference storage is not wired.
- Do not publish this starter as a production app yet.

## Suggested next implementation stages
1. Wire imported local files into the audio handler and player state.
2. Add persistent library models for favorites, playlists, queue and history.
3. Add playback event tracking and derive statistics from actual listening duration.
4. Add artwork extraction and dynamic gradient themes.
5. Complete Android/iOS background audio configuration and test on physical devices.
6. Add backend/authentication only if account sync or social features are needed.
7. Integrate a licensed music catalogue/API if streaming from a remote catalogue is required.

## Run
Install Flutter SDK, then from this folder:

```bash
flutter pub get
flutter run
```

Use Android Studio / Xcode for native device builds. iOS builds require macOS and Xcode.
